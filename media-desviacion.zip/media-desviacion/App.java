import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public class App {
    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        DecimalFormat nuevoFormato = new DecimalFormat("#.000000");
        // Iniciar la estructura de datos
        ArrayList<Double> listaDatos = new ArrayList<>();
        // Variables
        int opcionIngreso;
        double numeroIngresado = 0.0;
        char opcionContinuar = 'n';
        App llamaMetodos = new App();
        // Resto de código
        do {
            System.out.println("¿Qué quieres hacer?");
            System.out.println("1. Ingresar datos mediante teclado.");
            System.out.println("2. Ingresar datos mediante un archivo de texto.");
            System.out.println("3. Calcular media de los datos.");
            System.out.println("4. Calcular desviación de los datos.");
            System.out.println("5. Cancelar y salir.");
            System.out.print("Opción > ");
            opcionIngreso = t.nextInt();
            t.nextLine();
            switch (opcionIngreso) {
                case 1:
                    System.out.println("-----------------------------------------------------");
                    do {
                        System.out.print("Ingresa el número > ");
                        numeroIngresado = t.nextDouble();
                        // Guardar en la estructura de datos
                        listaDatos.add(numeroIngresado);
                        System.out.println("¡Dato agregado con éxito!");
                        System.out.print("¿Quieres ingresar otro número? (s/n) > ");
                        opcionContinuar = t.next().charAt(0);
                    } while (opcionContinuar != 'n');
                    System.out.println("-----------------------------------------------------");
                    break;
                case 2:
                    
                    System.out.println("-----------------------------------------------------");
                    System.out.println("Ingresa el nombre de tu archivo: ");
                    System.out.println("Ej. mi-archivo.txt");
                    System.out.print("Escribe > ");
                    String archivo = t.nextLine();

                    try (FileReader frArchivo = new FileReader("resources/" + archivo)) {
                        BufferedReader brArchivo = new BufferedReader(frArchivo);
                        String numLinea;
                        while ((numLinea = brArchivo.readLine()) != null) {
                            numeroIngresado = Double.parseDouble(numLinea);
                            listaDatos.add(numeroIngresado);
                        }
                        System.out.println("¡Los datos se han agregado con éxito!");
                    } catch (Exception e) {
                        System.out.println("ERROR. " + e.getMessage());
                    }
                    System.out.println("-----------------------------------------------------");
                    break;
                case 3:
                    System.out.println("-----------------------------------------------------");
                    if (!listaDatos.isEmpty()) {
                        double media = llamaMetodos.calcularMedia(listaDatos);
                        System.out.println("La media de los datos es: " + nuevoFormato.format(media));
                    } else {
                        System.out.println("No hay ningún dato guardado.");
                    }
                    System.out.println("-----------------------------------------------------");
                    break;
                case 4:
                    System.out.println("-----------------------------------------------------");
                    if (!listaDatos.isEmpty()) {
                        double dvMedia = llamaMetodos.calcularDesviacionMedia(listaDatos);
                        double dvEstandar = llamaMetodos.calcularDesviacionEstandar(listaDatos);
                        System.out.println("La desviación media de los datos es: " + nuevoFormato.format(dvMedia));
                        System.out
                                .println("La desviación estándar de los datos es: " + nuevoFormato.format(dvEstandar));
                    } else {
                        System.out.println("No hay ningún dato guardado.");
                    }

                    System.out.println("-----------------------------------------------------");
                    break;
                case 5:
                    System.out.println("-----------------------------------------------------");
                    System.out.println("¡Saliste del sistema!");
                    break;
                default:
                    System.out.println("-----------------------------------------------------");
                    System.out.println("INCORRECTO. Elige una opción válida.");
                    System.out.println("-----------------------------------------------------");
                    break;
            }
        } while (opcionIngreso != 5);
        t.close();
    }

    public double calcularMedia(ArrayList<Double> listaDatos) {
        double acumulador = 0;
        for (Double dato : listaDatos) {
            acumulador += dato;
        }
        return acumulador / (listaDatos.size());
    }

    public double calcularDesviacionMedia(ArrayList<Double> listaDatos) {
        double media = calcularMedia(listaDatos);
        double acumulador = 0;
        for (Double dato : listaDatos) {
            acumulador += Math.abs(dato - media);
        }
        return acumulador / listaDatos.size();
    };

    public double calcularDesviacionEstandar(ArrayList<Double> listaDatos) {
        double media = calcularMedia(listaDatos);
        double acumulador = 0;
        for (Double dato : listaDatos) {
            acumulador += Math.pow(Math.abs(dato - media), 2);
        }
        return Math.sqrt(acumulador / (listaDatos.size() - 1));
    };
}